# Como publicar o Draw no GitHub

Nesta pasta:

- `draw/`: o código, pronto para o repositório (já sem `bin`, `dist`, `node_modules` e o FUNDING.yml do Neutralino)
- `release-v1.0.0/`: os 4 instaladores, para anexar na Release (não vão no código)

## 1. Criar o repositório

1. Entre em https://github.com/new
2. Repository name: `draw`
3. Description: `Editor vetorial gratuito em português: navegador, Windows e Linux. Abre .cdr e exporta PDF, SVG, EPS e PNG.`
4. Deixe **Public** e NÃO marque "Add a README", ".gitignore" nem "license" (já estão na pasta)
5. Clique em **Create repository**

## 2. Enviar o código

1. Na página do repositório vazio, clique no link **uploading an existing file**
2. Abra a pasta `draw` (esta aqui ao lado), selecione TUDO que está dentro dela (Ctrl+A) e arraste para a página
   - O `.gitignore` é um arquivo oculto: se não aparecer, no Explorador vá em Exibir › Mostrar › Itens ocultos
3. Em "Commit changes" escreva `Draw 1.0.0` e clique em **Commit changes**

## 3. Publicar os instaladores (Release)

1. No repositório, menu da direita › **Releases** › **Create a new release**
2. Choose a tag: digite `v1.0.0` e clique em "Create new tag"
3. Release title: `Draw 1.0.0`
4. Arraste os 4 arquivos da pasta `release-v1.0.0`
5. Na descrição, cole:

```
Primeira versão pública do Draw, editor vetorial gratuito em português.

**Downloads**
- Draw-Setup.exe: instalador para Windows 10 e 11 (não pede administrador)
- Draw-Windows.exe: versão portátil, abre sem instalar
- draw_1.0.0_amd64.deb: Ubuntu, Debian, Mint (`sudo apt install ./draw_1.0.0_amd64.deb`)
- draw-1.0.0-linux-x64.tar.gz: outras distribuições (extraia e rode `./install.sh`)

Ou use direto no navegador: https://draw.mais.live

No Windows pode aparecer o aviso do SmartScreen: clique em "Mais informações" › "Executar assim mesmo".
```

6. Clique em **Publish release**

## 4. Deixar o repositório fácil de achar

Na página inicial do repositório, clique na engrenagem ao lado de **About**:

- Website: `https://draw.mais.live`
- Topics: `vector-editor` `svg` `pdf` `design` `graphic-design` `neutralinojs` `portuguese` `cdr` `offline` `desktop-app`

## 5. Divulgar

Texto curto para redes sociais e grupos:

> Fiz o Draw, um editor vetorial gratuito e em português. Roda no navegador, no Windows e no Linux, funciona sem internet, abre arquivos .cdr e exporta PDF para gráfica. Código aberto no GitHub:
> https://github.com/SEU-USUARIO/draw
> Testar agora: https://draw.mais.live

Lugares que costumam dar retorno: grupos de comunicação visual e gráfica rápida no Facebook e WhatsApp, r/brdev e r/design_br no Reddit, TabNews (tabnews.com.br) e o seu Instagram.
Não use o nome nem o logotipo da Corel/CorelDRAW na divulgação.
